# C# Multiple Choice Quiz Game Tutorial by Mohammed

In this project we will makea simple quiz game in windows form. This will be a multiple choice game where you are asked a question and you have 4 variations of answers on the screen.

#Installation:
SimpleQuizGame\quizGame\bin\Release\application.exe

#Screenshots:
![Screenshot 2023-03-19 155116](https://user-images.githubusercontent.com/87497268/226176490-177ac0bc-2da3-4fe1-9b6b-199d7e83357a.png)
![Screenshot 2023-03-19 155129](https://user-images.githubusercontent.com/87497268/226176493-ec8bb64d-d995-440e-8029-7fcdff44adb8.png)
![Screenshot 2023-03-19 155204](https://user-images.githubusercontent.com/87497268/226176495-be692cb6-61fa-4264-8727-c8ac7885d8e1.png)
